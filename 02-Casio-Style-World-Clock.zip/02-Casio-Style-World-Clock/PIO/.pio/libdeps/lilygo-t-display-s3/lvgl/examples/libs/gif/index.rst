Open a GIF image from file and variable
"""""""""""""""""""""""""""""""""""""""""""""""

.. lv_example:: libs/gif/lv_example_gif_1
  :language: c

