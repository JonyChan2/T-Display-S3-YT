
Keyboard with text area
"""""""""""""""""""""""

.. lv_example:: widgets/keyboard/lv_example_keyboard_1
  :language: c

